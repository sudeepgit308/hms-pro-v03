package com.sudeep.dao;

import java.util.List;

import com.sudeep.model.Employee;

public interface EmployeeDao {
	
	public Employee saveEmployee(Employee emp);
	
//	public List<Employee> getAllEmployees();

}
