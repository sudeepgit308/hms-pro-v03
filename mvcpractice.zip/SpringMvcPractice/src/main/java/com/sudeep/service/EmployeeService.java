package com.sudeep.service;

import com.sudeep.bean.EmployeeBean;

public interface EmployeeService {
	
	public EmployeeBean save(EmployeeBean e); 

}
